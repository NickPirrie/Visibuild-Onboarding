
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/state.js
import { getStore } from "@netlify/blobs";
var STORE_NAME = "onboarding-portal";
var KEY = "state";
var state_default = async (req) => {
  const store = getStore(STORE_NAME);
  if (req.method === "GET") {
    const data = await store.get(KEY, { type: "json" });
    return new Response(JSON.stringify(data || null), {
      headers: { "content-type": "application/json", "cache-control": "no-store" }
    });
  }
  if (req.method === "POST" || req.method === "PUT") {
    let body;
    try {
      body = await req.json();
    } catch {
      return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400 });
    }
    body.updatedAt = Date.now();
    await store.setJSON(KEY, body);
    return new Response(JSON.stringify({ ok: true, updatedAt: body.updatedAt }), {
      headers: { "content-type": "application/json" }
    });
  }
  return new Response("Method not allowed", { status: 405 });
};
var config = { path: "/.netlify/functions/state" };
export {
  config,
  state_default as default
};
